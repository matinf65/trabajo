from django.urls import path
from . import views

app_name = 'finanzas'

urlpatterns = [
    path('simulador/', views.simulador, name='simulador'),
]
