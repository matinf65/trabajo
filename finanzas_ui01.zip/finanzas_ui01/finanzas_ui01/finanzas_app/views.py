from django.shortcuts import render

TRANSACCIONES_DEMO = [
    {'tipo': 'ingreso', 'categoria': 'Sueldo',            'descripcion': 'Sueldo mensual',    'monto': 1200000},
    {'tipo': 'gasto',   'categoria': 'Arriendo',          'descripcion': 'Arriendo dpto',     'monto': 450000},
    {'tipo': 'gasto',   'categoria': 'Alimentación',      'descripcion': 'Supermercado',      'monto': 120000},
    {'tipo': 'gasto',   'categoria': 'Transporte',        'descripcion': 'Bencina',           'monto': 60000},
    {'tipo': 'gasto',   'categoria': 'Servicios básicos', 'descripcion': 'Luz y agua',        'monto': 35000},
    {'tipo': 'gasto',   'categoria': 'Entretenimiento',   'descripcion': 'Streaming',         'monto': 15000},
]


def simulador(request):
    saldo_inicial  = 500000
    total_ingresos = sum(t['monto'] for t in TRANSACCIONES_DEMO if t['tipo'] == 'ingreso')
    total_gastos   = sum(t['monto'] for t in TRANSACCIONES_DEMO if t['tipo'] == 'gasto')
    saldo_final    = saldo_inicial + total_ingresos - total_gastos
    return render(request, 'finanzas_app/simulador.html', {
        'transacciones':  TRANSACCIONES_DEMO,
        'saldo_inicial':  saldo_inicial,
        'total_ingresos': total_ingresos,
        'total_gastos':   total_gastos,
        'saldo_final':    saldo_final,
    })
